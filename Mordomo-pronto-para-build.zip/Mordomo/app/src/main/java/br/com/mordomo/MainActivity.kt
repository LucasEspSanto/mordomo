package br.com.mordomo

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var h = 6
    private var m = 30
    private lateinit var horaBtn: Button
    private lateinit var sw: Switch

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        h = Scheduler.hour(this)
        m = Scheduler.minute(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(24), dp(48), dp(24), dp(24))
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(16)
            root.addView(v, lp)
        }

        val titulo = TextView(this)
        titulo.text = "Mordomo"
        titulo.textSize = 28f
        add(titulo)

        sw = Switch(this)
        sw.text = "Resumo matinal ativado"
        sw.isChecked = Scheduler.isOn(this)
        sw.setOnCheckedChangeListener { _, _ -> aplicar() }
        add(sw)

        horaBtn = Button(this)
        horaBtn.setOnClickListener {
            TimePickerDialog(this, { _, hh, mm -> h = hh; m = mm; aplicar() }, h, m, true).show()
        }
        add(horaBtn)

        val testar = Button(this)
        testar.text = "Testar agora"
        testar.setOnClickListener { startForegroundService(Intent(this, BriefingService::class.java)) }
        add(testar)

        val bateria = Button(this)
        bateria.text = "Liberar uso de bateria (recomendado)"
        bateria.setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        add(bateria)

        setContentView(root)
        atualizarHora()
    }

    private fun atualizarHora() {
        horaBtn.text = "Horário: %02d:%02d".format(h, m)
    }

    private fun aplicar() {
        atualizarHora()
        Scheduler.save(this, sw.isChecked, h, m)
        if (!Scheduler.schedule(this)) {
            Toast.makeText(this, "O Android recusou o alarme exato.", Toast.LENGTH_LONG).show()
        } else if (sw.isChecked) {
            Toast.makeText(this, "Agendado para %02d:%02d".format(h, m), Toast.LENGTH_SHORT).show()
        }
    }
}
