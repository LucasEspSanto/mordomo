package br.com.mordomo

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

object Scheduler {
    private fun prefs(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun isOn(c: Context) = prefs(c).getBoolean("on", false)
    fun hour(c: Context) = prefs(c).getInt("h", 6)
    fun minute(c: Context) = prefs(c).getInt("m", 30)

    fun save(c: Context, on: Boolean, h: Int, m: Int) {
        prefs(c).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).apply()
    }

    private fun firePi(c: Context) = PendingIntent.getBroadcast(
        c, 0, Intent(c, AlarmReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    /** Agenda a próxima ocorrência (ou cancela, se desligado). Retorna false se o Android recusar. */
    fun schedule(c: Context): Boolean {
        val am = c.getSystemService(AlarmManager::class.java)
        if (!isOn(c)) {
            am.cancel(firePi(c))
            return true
        }
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, hour(c))
        cal.set(Calendar.MINUTE, minute(c))
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)

        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, show), firePi(c))
            true
        } catch (e: SecurityException) {
            false
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        c.startForegroundService(Intent(c, BriefingService::class.java))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.schedule(c)
    }
}
