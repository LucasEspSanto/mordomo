package br.com.mordomo

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.roundToInt

object Briefing {
    // Jundiaí/SP (Medeiros). Para afinar, copie as coordenadas do Google Maps.
    private const val LAT = -23.1864
    private const val LON = -46.8842

    /** Devolve sempre um texto: o resumo completo ou, se a rede falhar, só a hora. */
    fun build(): String {
        repeat(3) {
            try {
                return compose()
            } catch (e: Exception) {
                Thread.sleep(4000)
            }
        }
        return "${saudacao()}, senhor. ${horaFalada()}. Não consegui obter a previsão do tempo."
    }

    private fun compose(): String {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON" +
            "&current=temperature_2m" +
            "&hourly=temperature_2m,precipitation_probability,weather_code" +
            "&daily=temperature_2m_max,temperature_2m_min" +
            "&timezone=auto&forecast_days=1"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 10000
        conn.readTimeout = 10000
        val json = try {
            JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
        } finally {
            conn.disconnect()
        }

        val agora = json.getJSONObject("current").getDouble("temperature_2m").roundToInt()
        val hourly = json.getJSONObject("hourly")
        val temps = hourly.getJSONArray("temperature_2m")
        val probs = hourly.getJSONArray("precipitation_probability")
        val codes = hourly.getJSONArray("weather_code")
        val daily = json.getJSONObject("daily")
        val tmin = daily.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
        val tmax = daily.getJSONArray("temperature_2m_max").getDouble(0).roundToInt()

        val sb = StringBuilder("${saudacao()}, senhor. ${horaFalada()}. Agora faz ${graus(agora)}. ")
        var guardaChuva = false
        val periodos = listOf("De manhã" to 6..11, "À tarde" to 12..17, "À noite" to 18..23)

        for ((nome, horas) in periodos) {
            val temp = horas.map { temps.getDouble(it) }.average().roundToInt()
            val chuva = horas.maxOf { probs.optInt(it, 0) }
            val codigo = horas.maxOf { codes.optInt(it, 0) }
            val inicio = horas.firstOrNull { probs.optInt(it, 0) >= 50 || codes.optInt(it, 0) >= 61 }
            val ceu = if (inicio == null && codigo >= 51) "nublado" else descricao(codigo)

            sb.append("$nome, $ceu, ${graus(temp)}")
            when {
                inicio != null -> {
                    guardaChuva = true
                    sb.append(if (chuva >= 70) ", com alta chance de chuva" else ", com chance de chuva")
                    sb.append(", a partir das $inicio horas")
                }
                chuva >= 30 -> sb.append(", com pequena chance de chuva")
                else -> sb.append(", sem chuva")
            }
            sb.append(". ")
        }

        sb.append("Mínima de ${graus(tmin)} e máxima de ${graus(tmax)}. ")
        if (guardaChuva) sb.append("Leve o guarda-chuva.")
        return sb.toString()
    }

    // Códigos WMO usados pela Open-Meteo
    private fun descricao(c: Int) = when (c) {
        0 -> "céu limpo"
        1 -> "céu quase limpo"
        2 -> "parcialmente nublado"
        3 -> "nublado"
        45, 48 -> "neblina"
        in 51..57 -> "garoa"
        in 61..67 -> "chuva"
        in 71..77, 85, 86 -> "neve"
        in 80..82 -> "pancadas de chuva"
        in 95..99 -> "trovoadas"
        else -> "tempo instável"
    }

    private fun graus(t: Int) = if (abs(t) == 1) "$t grau" else "$t graus"

    private fun saudacao() = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
        in 5..11 -> "Bom dia"
        in 12..17 -> "Boa tarde"
        else -> "Boa noite"
    }

    private fun horaFalada(): String {
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val base = if (h == 1) "É 1 hora" else "São $h horas"
        return when (m) {
            0 -> base
            1 -> "$base e 1 minuto"
            30 -> "$base e meia"
            else -> "$base e $m minutos"
        }
    }
}
