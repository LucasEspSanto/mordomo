package br.com.mordomo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class BriefingService : Service(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var text = ""
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("mordomo", "Mordomo", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "mordomo")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Mordomo")
            .setContentText("Preparando o resumo da manhã…")
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }

        Scheduler.schedule(this)                    // já deixa o alarme de amanhã marcado
        main.postDelayed({ stopSelf() }, 120_000)   // trava de segurança

        Thread {
            text = Briefing.build()
            main.post { tts = TextToSpeech(this, this) }
        }.start()
        return START_NOT_STICKY
    }

    override fun onInit(status: Int) {
        val t = tts
        if (status != TextToSpeech.SUCCESS || t == null) {
            stopSelf()
            return
        }
        t.setLanguage(Locale.forLanguageTag("pt-BR"))
        t.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { stopSelf() }
            override fun onError(utteranceId: String?) { stopSelf() }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "resumo")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
